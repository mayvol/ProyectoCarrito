//
//  SegundoViewController.swift
//  Proyecto02
//
//  Created by Macbook on 3/8/19.
//  Copyright © 2019 AcuaMod. All rights reserved.
//

import UIKit

class SegundoViewController: UIViewController {

    var dato: Producto
    var firstView : ViewController!
    override func viewDidLoad() {
        super.viewDidLoad()
        descripcion.text = dato.descripcion
        nombre.text = dato.nombre
        foto.image = UImage(named: dato.foto)
        foto.layer.cornerRadius = 40
        foto.clipsToBounds = true
    }

    @IBAction func X() {
        dismiss(animated: true, completion: nil)
    }
    
}
