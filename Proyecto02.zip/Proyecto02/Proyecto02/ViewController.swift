//
//  ViewController.swift
//  Proyecto02
//
//  Created by Macbook on 3/8/19.
//  Copyright © 2019 AcuaMod. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{
    
    @IBOutlet weak var Carrito: UIImageView!
    @IBOutlet weak var Icon: UIImageView!
    @IBOutlet weak var tablita: UITableView!
    @IBOutlet weak var etiqueta: UILabel!
    @IBOutlet weak var etiqueta2: UILabel!

    var Candy: [Producto] = [
        Producto(nombre: "Pulparindo", descripcion: "Dulce sabor a tamarindo, con sal y chile", precio: 5.0, foto: "pulparindo"),
        Producto(nombre: "Mazapan", descripcion: "Dulce de cacahuate, 50 gr.", precio: 6.0, foto: "Mazapan"),
        Producto(nombre: "Pica Fresa", descripcion: "Gomitas confitadas con chile", precio: 2.50, foto: "picafresa"),
        Producto(nombre: "Pelon Pelo Rico", descripcion: "Dulce enchilado sabor a tamarindo, 30 gr." , precio: 7.50, foto: "pelonpelorico"),
        Producto(nombre: "Bocadin", descripcion: "Galleta cubierta de chocolate", precio: 6.0, foto: "bocadin"),
        Producto(nombre: "Clorets", descripcion: "Goma de mazcar sin azucar, sabor menta", precio: 2.0, foto: "clorets"),
        Producto(nombre: "Rockaleta", descripcion: "Paleta enchilada con centro de goma de mascar", precio: 10.0, foto: "rokaleta"),
        Producto(nombre: "Mamut", descripcion: "Galleta con malvavisco cubierta de chocolate", precio: 5.50, foto: "mamut"),
        Producto(nombre: "Skwinkles", descripcion: "Dulce enchilado sabor sandia", precio: 6.0, foto: "skwinkles"),
        Producto(nombre: "Mini Takis", descripcion: "Fritura enchilada, 35gr.", precio: 7.0, foto: "takis")
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tablita.backgroundColor = .clear
      
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Candy.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        cell.backgroundColor = .clear
        cell.textLabel?.text = Candy[indexPath.row].nombre
        cell.textLabel?.text = Candy[indexPath.row].descripcion
        cell.imageView?.image = UIImage(named: Candy[indexPath.row].foto)
        
        return cell
    }
}
