//
//  Producto.swift
//  Proyecto02
//
//  Created by Macbook on 3/8/19.
//  Copyright © 2019 AcuaMod. All rights reserved.
//

import Foundation

struct Producto{
    var nombre: String
    var descripcion: String
    var precio: Double = 0.0
    var foto: String
}

