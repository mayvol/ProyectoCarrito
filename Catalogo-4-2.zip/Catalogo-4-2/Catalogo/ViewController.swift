//
//  ViewController.swift
//  Catalogo
//
//  Created by Germán Santos Jaimes on 2/25/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var tablita: UITableView!
    @IBOutlet weak var etiqueta: UILabel!
    
    var alumnos: [Alumno] = [
        Alumno(nombre:"Pedro 👦🏻", apellidos: "Pérez", promedio: 0.0, foto: "images" ),
        Alumno(nombre: "Juan 👨🏻", apellidos: "Juanes", promedio: 0.0, foto: "images"),
        Alumno(nombre: "Lola 👩🏻", apellidos: "Salinas", promedio: 0.0, foto: "images")
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        promedio()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        promedio()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return alumnos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        
        cell.textLabel?.text = alumnos[indexPath.row].nombre
        cell.imageView?.image = UIImage(named: alumnos[indexPath.row].foto)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath:/*censa los tap*/ IndexPath) {
        //etiqueta.text = alumnos[indexPath.row].nombre
        //let cell = tablita.cellForRow(at: indexPath)
        
        //closure
        let opcionMenu = UIAlertController(title: "Reprobar alumnos", message: "¿Reprobamos a este alumno?", preferredStyle: .alert)
        present(opcionMenu,animated: true, completion: nil)
        
        let cancelAction = UIAlertAction(title: "Cancelar", style: .cancel, handler: nil)
        let okAction = UIAlertAction(title: "OK", style: .default) { (action : UIAlertAction) in
            let celda = tableView.cellForRow(at: indexPath)
            
            if celda?.accessoryType.rawValue == 0{
                celda?.accessoryType = .checkmark
            }else{
                celda?.accessoryType = .none
            }
        self.performSegue(withIdentifier: "toTwo", sender: self)
        }
        
        opcionMenu.addAction(cancelAction)
        opcionMenu.addAction(okAction)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let indexPath = tablita.indexPathForSelectedRow
        let secondView = segue.destination as? SecondViewController
        secondView?.dato = alumnos[(indexPath?.row)!]
        secondView?.firstView = self
    }
    
    func promedio(){
        var promedio = 0.0
        var total = 0.0
        for alumno in alumnos{
            total = total + alumno.promedio
        }
        promedio = total / Double(alumnos.count)
        etiqueta.text = String(promedio)
    }
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if identifier == "toTwo"{
            return false
        }
        return true
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return CGFloat(100)
    }

}

