
import Foundation

struct Producto{
    var nombre: String
    var descripcion: String
    var precio: Int = 0
    var foto: String
}

