
import UIKit

class SegundoViewController: UIViewController {

    @IBOutlet weak var precio2: UILabel!
    @IBOutlet weak var foto: UIImageView!
    @IBOutlet weak var descripcion: UILabel!
    @IBOutlet weak var Cantidad: UILabel!
    @IBOutlet weak var totalTwo: UILabel!
    var dato: Producto!
    var firstView : ViewController!
    var cantidadProducto: Int = 0
    var cantidadPorProducto: Int = 0
    var precioEntero: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        precioEntero = Int(dato.precio)
        precio2.text = "\(dato.precio)"
        descripcion.text = dato.descripcion
        foto.image = UIImage(named: dato.foto)
        foto.layer.cornerRadius = 40
        foto.clipsToBounds = true
    }


    @IBAction func aumentar(_ sender: UIStepper) {
        cantidadProducto = Int(sender.value)
        Cantidad.text = "\(cantidadProducto)"
        print(cantidadProducto)
        cantidadPorProducto = cantidadProducto * precioEntero
        print(cantidadPorProducto)
        totalTwo.text = "\(cantidadPorProducto)"
    }
    @IBAction func AgregarCarrito(_ sender: UIButton) {
        firstView.totalProductos += cantidadProducto
        firstView.totalPrecio += cantidadPorProducto
        dismiss(animated: true, completion: nil)
    }
    func acumular(){
    firstView.totalProductos += cantidadProducto
    firstView.totalPrecio += cantidadPorProducto
    }
    @IBAction func X() {

        dismiss(animated: true, completion: nil)
        
    }
}
