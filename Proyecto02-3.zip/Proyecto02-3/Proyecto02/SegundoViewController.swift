
import UIKit

class SegundoViewController: UIViewController {

    @IBOutlet weak var foto: UIImageView!
   
    @IBOutlet weak var descripcion: UILabel!
       var dato: Producto!
     var firstView : ViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       // nombre.text = dato.nombre
        descripcion.text = dato.descripcion
        foto.image = UIImage(named: dato.foto)
        foto.layer.cornerRadius = 40
        foto.clipsToBounds = true
    }

    @IBAction func X() {
        dismiss(animated: true, completion: nil)
    }
}
