
import UIKit

class SegundoViewController: UIViewController {

    @IBOutlet weak var foto: UIImageView!
    @IBOutlet weak var Cantidad: UITextField!
    @IBOutlet weak var descripcion: UILabel!
       var dato: Producto!
     var firstView : ViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //nombre.text = dato.nombre
        descripcion.text = dato.descripcion
        foto.image = UIImage(named: dato.foto)
        foto.layer.cornerRadius = 40
        foto.clipsToBounds = true
    }
    @IBAction func AgregarCarrito(_ sender: UIButton) {
        if let numero = Cantidad.text {
            let indexPath = firstView.tablita.indexPathForSelectedRow
            firstView.Candy[(indexPath?.row)!].precio = Double (numero) ?? <#default value#>
        }
    
    }
    func acumulador(){
            var total = 0.0
            for producto in Producto {
                total = total + alumno.promedio
            }
    }

    
    @IBAction func X() {
        dismiss(animated: true, completion: nil)
    }
}
